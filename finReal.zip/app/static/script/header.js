// for the user icon open
function extend() {
    document.getElementById("user_info").style.display = "block";
  }
  //  for user-icon close
  function closeModal() {
    document.getElementById("user_info").style.display = "none";
  }
  